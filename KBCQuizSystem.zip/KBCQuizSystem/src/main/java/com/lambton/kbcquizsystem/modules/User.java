package com.lambton.kbcquizsystem.modules;

public class User {
    private int user_id;
    private String first_name, last_name, email_id, phone_number, gender, role;

    public User(int id, String firstName, String lastName, String email, String phone, String gender, String role) {
        this.user_id = id;
        this.first_name = firstName;
        this.last_name = lastName;
        this.email_id = email;
        this.phone_number = phone;
        this.gender = gender;
        this.role = role;
    }

    // Getters and Setters
    public int getUser_id() { return user_id; }
    public String getFirst_name() { return first_name; }
    public String getLast_name() { return last_name; }
    public String getEmail_id() { return email_id; }
    public String getPhone_number() { return phone_number; }
    public String getGender() { return gender; }
    public String getRole() { return role; }
}
