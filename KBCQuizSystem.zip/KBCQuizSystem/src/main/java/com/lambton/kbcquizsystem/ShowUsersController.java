package com.lambton.kbcquizsystem;

import com.lambton.kbcquizsystem.modules.User;
import com.lambton.kbcquizsystem.utils.DatabaseConnector;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.*;

public class ShowUsersController {

    @FXML
    private TableView<User> userTable;

    @FXML
    private TableColumn<User, Integer> colId;
    @FXML
    private TableColumn<User, String> colFirstName;
    @FXML
    private TableColumn<User, String> colLastName;
    @FXML
    private TableColumn<User, String> colEmail;
    @FXML
    private TableColumn<User, String> colPhone;
    @FXML
    private TableColumn<User, String> colGender;
    @FXML
    private TableColumn<User, String> colRole;

    private ObservableList<User> userList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupTable();
        loadUsersFromDatabase();
    }

    private void setupTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("user_id"));
        colFirstName.setCellValueFactory(new PropertyValueFactory<>("first_name"));
        colLastName.setCellValueFactory(new PropertyValueFactory<>("last_name"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email_id"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));

        userTable.setItems(userList);
    }

    private void loadUsersFromDatabase() {
        try {
            Connection connection = DatabaseConnector.getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM users");

            while (resultSet.next()) {
                userList.add(new User(
                        resultSet.getInt("user_id"),
                        resultSet.getString("first_name"),
                        resultSet.getString("last_name"),
                        resultSet.getString("email_id"),
                        resultSet.getString("phone_number"),
                        resultSet.getString("gender"),
                        resultSet.getString("role")
                ));
            }

        } catch (Exception e) {
            showError("Database Error", "Error loading users from database: " + e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();

        if (selectedUser != null) {
            try {
                // Connect to the database
                Connection connection = DatabaseConnector.getConnection();
                String deleteQuery = "DELETE FROM users WHERE user_id = ?";

                // Use PreparedStatement to avoid SQL injection
                PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
                preparedStatement.setInt(1, selectedUser.getUser_id());

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    // Remove the user from the ObservableList
                    userList.remove(selectedUser);
                    showInfo("Delete", "User deleted successfully!");
                } else {
                    showError("Delete Failed", "No rows were affected. Please try again.");
                }

                // Close the database resources
                preparedStatement.close();
                connection.close();

                // Refresh the table
                refreshTable();

            } catch (Exception e) {
                showError("Database Error", "Error deleting user from database: " + e.getMessage());
            }
        } else {
            showError("Selection Error", "Please select a user to delete.");
        }
    }

    private void refreshTable() {
        userList.clear(); // Clear the existing data
        loadUsersFromDatabase(); // Reload data from the database
    }


    @FXML
    private void handleEdit() {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();

        if (selectedUser != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("edit-user.fxml"));
                Parent root = loader.load();

                // Pass the selected user to the EditUserController
                EditUserController controller = loader.getController();
                controller.setUser(selectedUser);

                Stage stage = new Stage();
                stage.setTitle("Edit User");
                stage.setScene(new Scene(root));
                stage.showAndWait();

                // Refresh the table after editing
                refreshTable();

            } catch (Exception e) {
                showError("Error", "Error opening edit user form: " + e.getMessage());
            }
        } else {
            showError("Selection Error", "Please select a user to edit.");
        }
    }


    @FXML
    protected void handleHistory() {
        try {
            QuizHistoryController controller = openWindow("quiz-history.fxml", "Quiz History");
            User selectedUser = userTable.getSelectionModel().getSelectedItem();
            if (selectedUser == null) {
                showError("Selection Error", "Please select a user to view quiz history.");
                return;
            }
            controller.setUserId(selectedUser.getUser_id());
        } catch (Exception e) {
            showError("Error", "Failed to open quiz history window: " + e.getMessage());
        }
    }

    private QuizHistoryController openWindow(String fxmlFile, String title) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle(title);
        stage.show();

        return loader.getController();
    }


    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
