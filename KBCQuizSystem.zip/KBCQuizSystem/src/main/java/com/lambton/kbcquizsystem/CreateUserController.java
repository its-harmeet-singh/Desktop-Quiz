package com.lambton.kbcquizsystem;

import com.lambton.kbcquizsystem.utils.DatabaseConnector;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class CreateUserController {

    @FXML
    private TextField firstNameField, lastNameField, emailField, phoneField, passwordField;

    @FXML
    private ComboBox<String> genderComboBox, roleComboBox;

    @FXML
    public void initialize() {
        genderComboBox.getItems().addAll("Male", "Female", "Other");
        roleComboBox.getItems().addAll("Admin", "Participant");
    }

    @FXML
    protected void onSubmitClick() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String email = emailField.getText();
        String phone = phoneField.getText();
        String gender = genderComboBox.getValue();
        String role = roleComboBox.getValue();
        String password = passwordField.getText();

        if (validateInputs(firstName, lastName, email, phone, gender, role, password)) {
            saveUserToDatabase(firstName, lastName, email, phone, gender, role, password);
        }
    }

    private boolean validateInputs(String firstName, String lastName, String email, String phone, String gender, String role, String password) {
        // Implement your validation logic
        return true;
    }

    private void saveUserToDatabase(String firstName, String lastName, String email, String phone, String gender, String role, String password) {
        String query = "INSERT INTO users (first_name, last_name, email_id, phone_number, gender, role, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnector.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, email);
            statement.setString(4, phone);
            statement.setString(5, gender);
            statement.setString(6, role);
            statement.setString(7, password); // Replace with hashed password

            statement.executeUpdate();
            showAlert(Alert.AlertType.INFORMATION, "Success", "User added successfully.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add user.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
