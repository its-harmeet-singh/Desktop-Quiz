package com.lambton.kbcquizsystem.modules;

public class Question {
    private int id, category_id;
    private String questionText;
    private String option1, option2, option3, option4, answer, difficulty;

    public Question(int id, int category_id, String questionText, String option1, String option2, String option3, String option4, String answer, String difficulty) {
        this.id = id;
        this.category_id = category_id;
        this.questionText = questionText;
        this.option1 = option1;
        this.option2 = option2;
        this.option3 = option3;
        this.option4 = option4;
        this.answer = answer;
        this.difficulty = difficulty;
    }

    public String getDifficulty(){
        return difficulty;
    }

    public int getCategory_id(){
        return category_id;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getOption1() {
        return option1;
    }

    public String getOption2() {
        return option2;
    }

    public String getOption3() {
        return option3;
    }

    public String getOption4() {
        return option4;
    }

    public String getAnswer() {
        return answer;
    }
}
