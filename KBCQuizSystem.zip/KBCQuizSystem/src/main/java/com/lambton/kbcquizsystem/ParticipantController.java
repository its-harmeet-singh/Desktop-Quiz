package com.lambton.kbcquizsystem;

import com.lambton.kbcquizsystem.modules.Question;
import com.lambton.kbcquizsystem.modules.QuizHistory;
import com.lambton.kbcquizsystem.modules.User;
import com.lambton.kbcquizsystem.utils.DatabaseConnector;
import com.lambton.kbcquizsystem.utils.QuizSession;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ParticipantController {

    @FXML
    private Label nameLabel;

    @FXML
    private Label badgeLabel;

    @FXML
    private ChoiceBox<String> categoryChoiceBox;

    @FXML
    private ChoiceBox<String> difficultyChoiceBox;

    @FXML
    private TableView<QuizHistory> quizHistoryTable;

    @FXML
    private TableColumn<QuizHistory, String> quizDateColumn, categoryColumn, difficultyColumn;

    @FXML
    private TableColumn<QuizHistory, Integer> scoreColumn;

    private User loggedInUser;

    public void setLoggedInUser(User user) {
        this.loggedInUser = user;

        // Set user details dynamically
        nameLabel.setText(user.getFirst_name() + " " + user.getLast_name());
        badgeLabel.setText("Gold");
        fetchCategories();
        populateDifficultyDropdown();
        setupQuizHistoryTable();
        fetchQuizHistory();
    }

    private void fetchCategories() {
        try (Connection connection = DatabaseConnector.getConnection()) {
            String query = "SELECT DISTINCT name FROM category";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                categoryChoiceBox.getItems().add(resultSet.getString("name"));
            }

            resultSet.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void populateDifficultyDropdown() {
        difficultyChoiceBox.getItems().addAll("Low", "Medium", "High");
    }

    private void setupQuizHistoryTable() {
        quizDateColumn.setCellValueFactory(new PropertyValueFactory<>("quizDate"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));
        difficultyColumn.setCellValueFactory(new PropertyValueFactory<>("difficulty"));

        quizHistoryTable.setStyle("-fx-cell-padding: 10px;");
    }

    private void fetchQuizHistory() {
        ObservableList<QuizHistory> historyList = FXCollections.observableArrayList();

        try (Connection connection = DatabaseConnector.getConnection()) {
            String query = "SELECT quiz_date, category, score, difficulty FROM quiz_history WHERE user_id = ? ORDER BY quiz_date DESC LIMIT 10";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, loggedInUser.getUser_id());
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String quizDate = resultSet.getDate("quiz_date").toString();
                String category = resultSet.getString("category");
                int score = resultSet.getInt("score");
                String difficulty = resultSet.getString("difficulty");
                historyList.add(new QuizHistory(quizDate, category, score, difficulty));
            }

            resultSet.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        quizHistoryTable.setItems(historyList);
    }

    @FXML
    private void onStartQuizClick() {
        String selectedCategory = categoryChoiceBox.getValue();
        String selectedDifficulty = difficultyChoiceBox.getValue();

        if (selectedCategory == null || selectedDifficulty == null) {
            showError("Selection Error", "Please select both category and difficulty to start the quiz.");
            return;
        }

        try (Connection connection = DatabaseConnector.getConnection()) {
            // Get category ID from the database
            String query = "SELECT id FROM category WHERE name = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, selectedCategory);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int categoryId = rs.getInt("id");

                // Set session data
                QuizSession.setCategoryId(categoryId);
                QuizSession.setDifficulty(selectedDifficulty);
                QuizSession.setUserId(loggedInUser.getUser_id());

                // Navigate to the quiz screen
                loadQuizScreen();
            } else {
                showError("Category Error", "Selected category does not exist in the database.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showError("Database Error", "An error occurred while fetching category details.");
        }
    }

    private void loadQuizScreen() {
        try {
            // Load the Quiz FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/lambton/kbcquizsystem/quiz.fxml"));
            Parent root = loader.load();

            // Set up the stage
            Stage stage = new Stage();
            stage.setTitle("Quiz");
            stage.setScene(new Scene(root));
            stage.show();

            // Close the current screen
            Stage currentStage = (Stage) categoryChoiceBox.getScene().getWindow();
            currentStage.close();
        } catch (Exception e) {
            e.printStackTrace();
            showError("Navigation Error", "Failed to load the quiz screen.");
        }
    }


    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
