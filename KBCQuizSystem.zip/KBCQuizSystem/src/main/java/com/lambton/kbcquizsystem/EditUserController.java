package com.lambton.kbcquizsystem;

import com.lambton.kbcquizsystem.modules.User;
import com.lambton.kbcquizsystem.utils.DatabaseConnector;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class EditUserController {

    @FXML
    private TextField firstNameField, lastNameField, emailField, phoneField;
    @FXML
    private ComboBox<String> genderComboBox, roleComboBox;

    private User selectedUser;

    public void setUser(User user) {
        this.selectedUser = user;

        // Prefill the form with user data
        firstNameField.setText(user.getFirst_name());
        lastNameField.setText(user.getLast_name());
        emailField.setText(user.getEmail_id());
        phoneField.setText(user.getPhone_number());

        // Set default values for dropdowns
        genderComboBox.setItems(FXCollections.observableArrayList("Male", "Female", "Other"));
        roleComboBox.setItems(FXCollections.observableArrayList("Admin", "Participant"));

        genderComboBox.setValue(user.getGender());
        roleComboBox.setValue(user.getRole());
    }

    @FXML
    private void handleSave() {
        try {
            // Update user data in the database
            Connection connection = DatabaseConnector.getConnection();
            String updateQuery = "UPDATE users SET first_name = ?, last_name = ?, email_id = ?, phone_number = ?, gender = ?, role = ? WHERE user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);

            preparedStatement.setString(1, firstNameField.getText());
            preparedStatement.setString(2, lastNameField.getText());
            preparedStatement.setString(3, emailField.getText());
            preparedStatement.setString(4, phoneField.getText());
            preparedStatement.setString(5, genderComboBox.getValue());
            preparedStatement.setString(6, roleComboBox.getValue());
            preparedStatement.setInt(7, selectedUser.getUser_id());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showInfo("Success", "User updated successfully!");
                closeWindow();
            } else {
                showError("Error", "Failed to update user. Please try again.");
            }

            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            showError("Database Error", "Error updating user: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) firstNameField.getScene().getWindow();
        stage.close();
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
