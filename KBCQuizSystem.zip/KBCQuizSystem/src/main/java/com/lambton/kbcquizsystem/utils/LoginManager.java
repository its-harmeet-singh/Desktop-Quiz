package com.lambton.kbcquizsystem.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginManager {

    public boolean login(String email, String password) {
        String query = "SELECT password_hash, role FROM users WHERE email_id = ?";
        try (Connection connection = DatabaseConnector.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String storedHash = resultSet.getString("password_hash");
                String role = resultSet.getString("role");

                // Validate the password (you'll need to hash and compare securely)
                if (storedHash.equals(password)) {
                    System.out.println("Login successful! User Role: " + role);
                    return true;
                } else {
                    System.out.println("Invalid password.");
                }
            } else {
                System.out.println("User not found.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
}

