package com.lambton.kbcquizsystem;

import com.lambton.kbcquizsystem.utils.DatabaseConnector;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AddQuestionController {

    @FXML
    private CheckBox newCategoryCheckBox;

    @FXML
    private TextField categoryNameField, questionField, option1Field, option2Field, option3Field, option4Field, answer;

    @FXML
    private ComboBox<String> categoryComboBox, difficultyComboBox;

    @FXML
    public void initialize() {
        // Populate difficulty levels
        difficultyComboBox.getItems().addAll("Low", "Medium", "High");

        // Populate existing categories
        loadExistingCategories();

        // Initially disable/enable fields appropriately
        categoryNameField.setDisable(true);
        categoryComboBox.setDisable(false);
    }

    @FXML
    protected void onCategoryToggle() {
        boolean isNewCategory = newCategoryCheckBox.isSelected();
        categoryNameField.setDisable(!isNewCategory);
        categoryComboBox.setDisable(isNewCategory);
    }

    @FXML
    protected void onSubmitClick() {
        String categoryName = newCategoryCheckBox.isSelected() ? categoryNameField.getText() : categoryComboBox.getValue();
        String question = questionField.getText();
        String option1 = option1Field.getText();
        String option2 = option2Field.getText();
        String option3 = option3Field.getText();
        String option4 = option4Field.getText();
        String ans = answer.getText();
        String difficulty = difficultyComboBox.getValue();

        if (validateInputs(categoryName, question, option1, option2, option3, option4, ans, difficulty)) {
            saveQuestionToDatabase(categoryName, question, option1, option2, option3, option4, ans, difficulty);
        }
    }

    @FXML
    protected void onClearClick() {
        clearForm();
    }

    @FXML
    protected void onAddAnotherClick() {
        onSubmitClick();
        clearForm();
    }

    private void loadExistingCategories() {
        System.out.println("Calling LoadExistingCategory");
        String query = "SELECT name FROM category";
        try (Connection connection = DatabaseConnector.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                categoryComboBox.getItems().add(resultSet.getString("name"));
                System.out.println(resultSet.getString("name"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private boolean validateInputs(String categoryName, String question, String option1, String option2, String option3, String option4, String ans, String difficulty) {
        if (categoryName == null || categoryName.isEmpty() ||
                question.isEmpty() || option1.isEmpty() || option2.isEmpty() ||
                option3.isEmpty() || option4.isEmpty() || ans.isEmpty() || difficulty == null) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields are required!");
            return false;
        }
        return true;
    }

    private void saveQuestionToDatabase(String categoryName, String question, String option1, String option2, String option3, String option4, String ans, String difficulty) {
        String insertCategoryQuery = "INSERT INTO category (name) VALUES (?) ON DUPLICATE KEY UPDATE name = name";
        String getCategoryIdQuery = "SELECT id FROM category WHERE name = ?";
        String insertQuestionQuery = "INSERT INTO question (category_id, question_text, option1, option2, option3, option4, answer, difficulty) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnector.getConnection()) {
            // Save category if needed
            int categoryId;
            try (PreparedStatement insertCategoryStmt = connection.prepareStatement(insertCategoryQuery);
                 PreparedStatement getCategoryIdStmt = connection.prepareStatement(getCategoryIdQuery)) {

                insertCategoryStmt.setString(1, categoryName);
                insertCategoryStmt.executeUpdate();

                getCategoryIdStmt.setString(1, categoryName);
                ResultSet resultSet = getCategoryIdStmt.executeQuery();
                if (resultSet.next()) {
                    categoryId = resultSet.getInt("id");
                } else {
                    throw new Exception("Category ID retrieval failed.");
                }
            }

            // Save question
            try (PreparedStatement insertQuestionStmt = connection.prepareStatement(insertQuestionQuery)) {
                insertQuestionStmt.setInt(1, categoryId);
                insertQuestionStmt.setString(2, question);
                insertQuestionStmt.setString(3, option1);
                insertQuestionStmt.setString(4, option2);
                insertQuestionStmt.setString(5, option3);
                insertQuestionStmt.setString(6, option4);
                insertQuestionStmt.setString(7, ans);
                insertQuestionStmt.setString(8, difficulty);
                insertQuestionStmt.executeUpdate();
            }

            showAlert(Alert.AlertType.INFORMATION, "Success", "Question added successfully.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add question.");
        }
    }

    private void clearForm() {
        questionField.clear();
        option1Field.clear();
        option2Field.clear();
        option3Field.clear();
        option4Field.clear();
        answer.clear();
        difficultyComboBox.setValue(null);
        if (!newCategoryCheckBox.isSelected()) {
            categoryComboBox.setValue(null);
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
