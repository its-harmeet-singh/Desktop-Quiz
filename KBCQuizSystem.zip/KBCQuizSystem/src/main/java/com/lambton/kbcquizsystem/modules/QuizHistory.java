package com.lambton.kbcquizsystem.modules;

public class QuizHistory {
    private String quizDate;
    private String category;
    private int score;
    private String difficulty;

    public QuizHistory(String quizDate, String category, int score, String difficulty) {
        this.quizDate = quizDate;
        this.category = category;
        this.score = score;
        this.difficulty = difficulty;
    }

    public String getQuizDate() { return quizDate; }
    public String getCategory() { return category; }
    public int getScore() { return score; }
    public String getDifficulty() { return difficulty; }
}