package com.lambton.kbcquizsystem.utils;

import com.lambton.kbcquizsystem.modules.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class QuizSession {
    private static int categoryId;
    private static String difficulty;
    private static int userId; // Store the logged-in user's ID

    public static int getCategoryId() {
        return categoryId;
    }

    public static void setCategoryId(int categoryId) {
        QuizSession.categoryId = categoryId;
    }

    public static String getDifficulty() {
        return difficulty;
    }

    public static void setDifficulty(String difficulty) {
        QuizSession.difficulty = difficulty;
    }

    public static int getUserId() {
        return userId;
    }

    public static void setUserId(int userId) {
        QuizSession.userId = userId;
    }

    public static User getLoggedInUser(int userId) {
        User user = null;
        try{
            Connection conn = DatabaseConnector.getConnection();
            String query = "SELECT user_id, first_name, email_id, last_name, phone_number, role, gender FROM users WHERE user_id = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String role = resultSet.getString("role");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                String email_id = resultSet.getString("email_id");
                String phone_number = resultSet.getString("phone_number");
                String gender = resultSet.getString("gender");

                user = new User(userId, firstName, lastName, email_id, phone_number, gender, role);
            }

        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
        return user;
    }
}
