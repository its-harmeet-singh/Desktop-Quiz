package com.lambton.kbcquizsystem;

import com.lambton.kbcquizsystem.modules.Question;
import com.lambton.kbcquizsystem.utils.DatabaseConnector;
import com.lambton.kbcquizsystem.utils.QuizSession;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class QuizController {
    @FXML
    private Label questionLabel;

    @FXML
    private RadioButton option1, option2, option3, option4;

    private ToggleGroup toggleGroup = new ToggleGroup();

    private List<Question> questions;
    private int currentIndex = 0;
    private int score = 0;

    public void initialize() {
        option1.setToggleGroup(toggleGroup);
        option2.setToggleGroup(toggleGroup);
        option3.setToggleGroup(toggleGroup);
        option4.setToggleGroup(toggleGroup);

        loadQuestions();
        displayQuestion();
    }

    private void loadQuestions() {
        questions = new ArrayList<>();
        try (Connection connection = DatabaseConnector.getConnection()) {
            String query = "SELECT * FROM question WHERE category_id = ? AND difficulty = ? ORDER BY RAND() LIMIT 10";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, QuizSession.getCategoryId());
            ps.setString(2, QuizSession.getDifficulty());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                questions.add(new Question(
                        rs.getInt("id"),
                        rs.getInt("category_id"),
                        rs.getString("question_text"),
                        rs.getString("option1"),
                        rs.getString("option2"),
                        rs.getString("option3"),
                        rs.getString("option4"),
                        rs.getString("answer"),
                        rs.getString("difficulty")
                ));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void displayQuestion() {
        if (currentIndex < questions.size()) {
            Question currentQuestion = questions.get(currentIndex);
            questionLabel.setText(currentQuestion.getQuestionText());
            option1.setText(currentQuestion.getOption1());
            option2.setText(currentQuestion.getOption2());
            option3.setText(currentQuestion.getOption3());
            option4.setText(currentQuestion.getOption4());
        } else {
            showResults();
        }
    }

    @FXML
    private void onNextClick() {
        RadioButton selected = (RadioButton) toggleGroup.getSelectedToggle();
        if (selected != null) {
            String selectedAnswer = selected.getText();
            if (selectedAnswer.equals(questions.get(currentIndex).getAnswer())) {
                score += 10;
            }
            currentIndex++;
            displayQuestion();
        } else {
            showAlert("Please select an answer!");
        }
    }

    @FXML
    private void showResults() {
        try {
            saveScoreToDatabase();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            //showError("Database Error", "Failed to save quiz results.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Quiz Completed");
        alert.setHeaderText("Your Score: " + score);
        alert.setContentText("Thanks for participating!");
        alert.showAndWait();

        navigateToParticipantView();
    }

    private void saveScoreToDatabase() throws Exception {
        try (Connection connection = DatabaseConnector.getConnection()) {
            String query = "INSERT INTO quiz_history (user_id, quiz_date, category, score, difficulty) VALUES (?, NOW(), ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, QuizSession.getUserId());
            ps.setString(2, getCategoryName(QuizSession.getCategoryId()));
            ps.setInt(3, score);
            ps.setString(4, QuizSession.getDifficulty());

            ps.executeUpdate();
        }
    }

    private String getCategoryName(int categoryId) throws Exception {
        String categoryName = "";
        try (Connection connection = DatabaseConnector.getConnection()) {
            String query = "SELECT name FROM category WHERE id = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, categoryId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                categoryName = rs.getString("name");
            }
        }
        return categoryName;
    }

    private void navigateToParticipantView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("participant-view.fxml"));
            Parent root = loader.load();

            ParticipantController participantController = loader.getController();
            participantController.setLoggedInUser(QuizSession.getLoggedInUser(QuizSession.getUserId())); // Pass the user back to the participant view

            Stage stage = new Stage();
            stage.setTitle("Participant View");
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) questionLabel.getScene().getWindow();
            currentStage.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setContentText(message);
        alert.showAndWait();
    }
}

