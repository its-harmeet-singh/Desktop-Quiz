package com.lambton.kbcquizsystem;

import com.lambton.kbcquizsystem.modules.QuizHistory;
import com.lambton.kbcquizsystem.utils.DatabaseConnector;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class QuizHistoryController {

    @FXML
    private TableView<QuizHistory> quizHistoryTable;
    @FXML
    private TableColumn<QuizHistory, String> quizDateColumn, categoryColumn, difficultyColumn;
    @FXML
    private TableColumn<QuizHistory, Integer> scoreColumn;

    private int selectedUserId;

    public void setUserId(int userId) {
        this.selectedUserId = userId;
        loadQuizHistory();
    }

    private void loadQuizHistory() {
        ObservableList<QuizHistory> historyList = FXCollections.observableArrayList();

        try {
            Connection connection = DatabaseConnector.getConnection();
            String query = "SELECT quiz_date, category, score, difficulty FROM quiz_history WHERE user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, selectedUserId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String quizDate = resultSet.getDate("quiz_date").toString();
                String category = resultSet.getString("category");
                int score = resultSet.getInt("score");
                String difficulty = resultSet.getString("difficulty");
                historyList.add(new QuizHistory(quizDate, category, score, difficulty));
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

        } catch (Exception e) {
            showError("Database Error", "Failed to load quiz history: " + e.getMessage());
        }

        quizHistoryTable.setItems(historyList);
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void initialize() {
        quizDateColumn.setCellValueFactory(new PropertyValueFactory<>("quizDate"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));
        difficultyColumn.setCellValueFactory(new PropertyValueFactory<>("difficulty"));
    }
}
