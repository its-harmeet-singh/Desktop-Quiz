package com.lambton.kbcquizsystem;

import com.lambton.kbcquizsystem.modules.User;
import com.lambton.kbcquizsystem.utils.DatabaseConnector;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    protected void onLoginButtonClick() {
        String email = emailField.getText();
        String password = passwordField.getText();

        User loggedInUser = validateLogin(email, password);
        if (loggedInUser != null) {
            if (loggedInUser.getRole().equals("Admin")) {
                loadScene("admin-view.fxml", "Admin Dashboard", loggedInUser);
            } else if (loggedInUser.getRole().equals("Participant")) {
                loadScene("participant-view.fxml", "Participant Dashboard", loggedInUser);
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid email or password.");
        }
    }

    private User validateLogin(String email, String password) {
        String query = "SELECT user_id, first_name, last_name, password_hash, role FROM users WHERE email_id = ?";
        try (Connection connection = DatabaseConnector.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String storedHash = resultSet.getString("password_hash");
                String role = resultSet.getString("role");

                if (storedHash.equals(password)) { // Replace with hashed password check
                    int userId = resultSet.getInt("user_id");
                    String firstName = resultSet.getString("first_name");
                    String lastName = resultSet.getString("last_name");
                    return new User(userId, firstName, lastName, email, null, null, role);
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    private void loadScene(String fxmlFile, String title, User user) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            // Pass the user object to the next controller
            if (fxmlFile.equals("participant-view.fxml")) {
                ParticipantController controller = loader.getController();
                controller.setLoggedInUser(user);
            }

            Stage stage = (Stage) emailField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
